
What you have to compile : main.cpp (main function), MemoryStructure.cpp, ScheduleProcessor.cpp, FirstFit.cpp, YourPolicy1.cpp, YourPolicy2.cpp
Header files : define.hpp, MemoryStructure.hpp, ScheduleProcessor.hpp, Policy.hpp, FirstFit.hpp, YourPolicy1.hpp, YourPolicy2.hpp

You don't have to compile sch_random.c, sch_greedy.c, sch_backnforth.c!
These are allocation / deallocation schdule files!

Please do not leak these source codes outward!